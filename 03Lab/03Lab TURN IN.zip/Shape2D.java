public interface Shape2D {
    // TODO: return the 2D area of the shape
    double area();

    // TODO: return the perimeter (total boundary length) of the shape
    double perimeter();
}
